#include <stdio.h>

int main{
    // Write C code here
    printf("Try programiz.pro");

    return 0;
}