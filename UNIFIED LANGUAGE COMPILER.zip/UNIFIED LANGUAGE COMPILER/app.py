from flask import Flask, render_template, request, jsonify
from compiler import CodeCompiler

app = Flask(__name__)
compiler = CodeCompiler()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run', methods=['POST'])
def run_code():
    data = request.json
    code = data.get('code')

    if not code.strip():
        return jsonify({'error': 'No code provided.'}), 400

    language = compiler.detect_language(code)
    output = compiler.run_code(code)

    return jsonify({
        'language': language,
        'output': output
    })

if __name__ == '__main__':
    app.run(debug=True)
