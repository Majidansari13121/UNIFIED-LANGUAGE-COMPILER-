import os
import subprocess
import sys

class CodeCompiler:
    def __init__(self):
        self.working_dir = os.path.dirname(os.path.abspath(__file__))
        
    def detect_language(self, code):
        code = code.lower()
        if '#include' in code and 'iostream' in code:
            return 'cpp'
        elif '#include' in code and 'stdio.h' in code:
            return 'c'
        elif "function " in code or "console.log" in code:
            return "javascript"
        elif "public class " in code or "system.out.println" in code or "public static void main" in code:
            return "java"
        elif 'print' in code or 'input' in code:
            return 'python'
        return 'unknown'
    
    

    def run_python(self, code):
        import io
        from contextlib import redirect_stdout
        try:
            # Create a string buffer to capture stdout
            f = io.StringIO()
            with redirect_stdout(f):
                if 'print' not in code:
                    result = eval(code)
                    return result
                else:
                    exec(code)
            output = f.getvalue()
            return output.strip() or "Executed"
        except Exception as e:
            return f"Python Error: {str(e)}"

    
    def run_cpp(self, code):
        try:
            temp_cpp = os.path.join(self.working_dir, 'temp_cpp.cpp')
            temp_exe = os.path.join(self.working_dir, 'temp_cpp.exe')

            with open(temp_cpp, 'w') as f:
                f.write(code)

            compiler = r"C:\MinGW\bin\g++.exe"

            # Check compiler availability
            try:
                subprocess.run([compiler, '--version'], check=True, capture_output=True, text=True)
            except FileNotFoundError:
                return "Error: C++ Compiler (g++) not found. Please install and add it to PATH."

            # 🔧 Compile the correct file
            compile_result = subprocess.run(
                        [compiler,temp_cpp , '-o', temp_exe],
                        capture_output=True,
                        text=True
            )

            if compile_result.returncode != 0:
                error_message = compile_result.stderr.strip() or compile_result.stdout.strip() or "Unknown compilation error."
                return f"Compilation Error:\n{error_message}"
                         
            # ▶️ Run the executable
            run_result = subprocess.run([temp_exe], capture_output=True, text=True)
            return run_result.stdout if run_result.returncode == 0 else f"Runtime Error: {run_result.stderr}"

        except subprocess.CalledProcessError as e:
            return f"Compilation Error (crash): {e.stderr}"
        except Exception as e:
            return f"C++ Error: {str(e)}"


    
    def run_javascript(self, code):
        try:
            file_path = os.path.join(self.working_dir, 'temp.js')
            with open(file_path, 'w') as f:
                f.write(code)
            result = subprocess.run(['node', file_path], capture_output=True, text=True)
            return result.stdout if result.returncode == 0 else f"JavaScript Error: {result.stderr}"
        except Exception as e:
            return f"JavaScript Execution Error: {str(e)}"
        
    def run_java(self, code):
       try:
        file_path = os.path.join(self.working_dir, 'Temp.java')
        with open(file_path, 'w') as f:
            f.write(code)

        # Compile the Java code using 'javac'
        compile_result = subprocess.run(['javac','Temp.java'], capture_output=True, text=True, cwd=self.working_dir)
        if compile_result.returncode != 0:
            return f"Java Compilation Error: {compile_result.stderr}"
         # Run Java class using -cp .
        run_result = subprocess.run(
            ['java', '-cp', '.', 'Temp'],
            capture_output=True,
            text=True,
            cwd=self.working_dir
        )

        # Run the compiled Java class using 'java'
        return run_result.stdout if run_result.returncode == 0 else f"Java Execution Error: {run_result.stderr}"
       except Exception as e:
            return f"Java Error: {str(e)}"


    def run_code(self, code):
        language = self.detect_language(code)
        
        if language == 'python':
            return self.run_python(code)
        elif language in ['cpp', 'c']:
            return self.run_cpp(code)
        elif language == 'javascript':
            return self.run_javascript(code)
        elif language == 'java':
            return self.run_java(code)
        else:
            return "Unsupported language"
