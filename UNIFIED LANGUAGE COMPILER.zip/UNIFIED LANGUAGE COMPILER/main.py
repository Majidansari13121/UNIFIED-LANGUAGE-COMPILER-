from compiler import CodeCompiler

def main():
    compiler = CodeCompiler()
    
    print("Enter your code (type 'RUN' on a new line to execute):")
    code_lines = []
    
    while True:
        try:
            line = input()
            if line.strip().upper() == 'RUN':
                break
            code_lines.append(line)
        except EOFError:
            break
    
    code = '\n'.join(code_lines)
    
    if not code.strip():
        print("No code entered!")
        return
    
    language = compiler.detect_language(code)
    
    print("\nExecuting code...")
    print("=" * 40)
    
    result = compiler.run_code(code)
    
    print(f"\nThis is your language: {language}")
    print("Here is the output:")
    print(result)
    
    print("=" * 40)

if __name__ == "__main__":
    while True:
        main()
        again = input("\nRun another code? (y/n): ")
        if again.lower() != 'y':
         break