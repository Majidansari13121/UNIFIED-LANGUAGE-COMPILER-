import os
import subprocess
import tempfile

class MultiLanguageCompiler:
    def __init__(self):
        self.language_extensions = {
            'python': '.py',
            'c': '.c',
            'cpp': '.cpp',
            'java': '.java',
            'javascript': '.js'
        }

    def detect_language(self, code):
        if not isinstance(code, str):
            return 'python'
            
        # Basic language detection based on keywords and syntax
        if 'public static void main' in code:
            return 'java'
        elif '#include' in code:
            return 'cpp' if 'cout' in code else 'c'
        elif 'console.log' in code:
            return 'javascript'
        else:
            return 'python'

    def compile_and_run(self, code):
        try:
            language = self.detect_language(code)
            extension = self.language_extensions[language]
            
            # Create temporary file
            with tempfile.NamedTemporaryFile(suffix=extension, delete=False, mode='w', encoding='utf-8') as temp_file:
                temp_file.write(code)
                temp_path = temp_file.name

            output = ""
            error = ""
            exe_path = ""

            try:
                if language == 'python':
                    result = subprocess.run(['python', temp_path], capture_output=True, text=True, timeout=30)
                    output = result.stdout if result.stdout else ""
                    error = result.stderr if result.stderr else ""
                
                elif language == 'c':
                    exe_path = temp_path[:-2] + '.exe'
                    compile_result = subprocess.run(['gcc', temp_path, '-o', exe_path], capture_output=True, text=True)
                    if compile_result.returncode == 0:
                        result = subprocess.run([exe_path], capture_output=True, text=True, timeout=30)
                        output = result.stdout
                        error = result.stderr
                    else:
                        error = compile_result.stderr
                
                elif language == 'cpp':
                    exe_path = temp_path[:-4] + '.exe'
                    compile_result = subprocess.run(['g++', temp_path, '-o', exe_path], capture_output=True, text=True)
                    if compile_result.returncode == 0:
                        result = subprocess.run([exe_path], capture_output=True, text=True, timeout=30)
                        output = result.stdout
                        error = result.stderr
                    else:
                        error = compile_result.stderr
                
                elif language == 'java':
                    compile_result = subprocess.run(['javac', temp_path], capture_output=True, text=True)
                    if compile_result.returncode == 0:
                        class_path = os.path.dirname(temp_path)
                        class_name = os.path.splitext(os.path.basename(temp_path))[0]
                        result = subprocess.run(['java', '-cp', class_path, class_name], capture_output=True, text=True, timeout=30)
                        output = result.stdout
                        error = result.stderr
                    else:
                        error = compile_result.stderr
                
                elif language == 'javascript':
                    result = subprocess.run(['node', temp_path], capture_output=True, text=True, timeout=30)
                    output = result.stdout
                    error = result.stderr

            except subprocess.TimeoutExpired:
                error = "Execution timed out (30 seconds limit)"
            except Exception as e:
                error = str(e)
            finally:
                # Clean up temporary files
                try:
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
                    if exe_path and os.path.exists(exe_path):
                        os.unlink(exe_path)
                except:
                    pass

            return {
                'language': language,
                'output': output.strip() if output else "",
                'error': error.strip() if error else ""
            }
        except Exception as e:
            return {
                'language': 'unknown',
                'output': '',
                'error': str(e)
            }

def main():
    compiler = MultiLanguageCompiler()
    
    print("Welcome to Multi-Language Compiler!")
    print("Enter your code (type 'EXIT' on a new line to finish):")
    
    code_lines = []
    while True:
        line = input()
        if line == 'EXIT':
            break
        code_lines.append(line)
    
    code = '\n'.join(code_lines)
    
    if code.strip():
        result = compiler.compile_and_run(code)
        print("\nDetected Language:", result['language'].upper())
        
        if result['error']:
            print("\nErrors:")
            print(result['error'])
        
        if result['output']:
            print("\nOutput:")
            print(result['output'])
    else:
        print("No code provided!")

if __name__ == "__main__":
    main()