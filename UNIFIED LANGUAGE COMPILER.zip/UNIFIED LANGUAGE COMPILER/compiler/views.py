from django.shortcuts import render
from .compiler_utils import MultiLanguageCompiler

def compiler_view(request):
    result = None
    code = ''
    
    if request.method == 'POST':
        try:
            code = request.POST.get('code', '')
            if code.strip():
                compiler = MultiLanguageCompiler()
                result = compiler.compile_and_run(code)
                
                # Convert None to empty string
                result['output'] = result['output'] or ''
                result['error'] = result['error'] or ''
                    
        except Exception as e:
            result = {
                'language': 'unknown',
                'output': '',
                'error': str(e)
            }
    
    context = {
        'result': result,
        'code': code
    }
    return render(request, 'compiler/compiler.html', context)