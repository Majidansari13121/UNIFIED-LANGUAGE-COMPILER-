import re
import subprocess
import os
import sys

class LanguageDetector:
    def __init__(self, source_code):
        self.source_code = source_code

    def detect_language(self):
        # Check for language-specific patterns
        if '#include' in self.source_code and ('stdio.h' in self.source_code or 'iostream' in self.source_code):
            return 'cpp' if 'iostream' in self.source_code else 'c'
        elif 'console.log' in self.source_code or 'let' in self.source_code or 'var' in self.source_code:
            return 'javascript'
        elif 'def' in self.source_code or 'print(' in self.source_code:
            return 'python'
        elif 'class' in self.source_code or 'public static void main' in self.source_code:
            return 'java'
        else:
            return 'unknown'

class SmartCompiler:
    def __init__(self, source_code,temp_dir):
        self.source_code = source_code
        self.detector = LanguageDetector(source_code)
        self.temp_dir = temp_dir 

    def parse_code(self):
        # Extract key elements from the code
        variables = re.findall(r'\b(?:var|let|const|int|float|double|string)\s+(\w+)', self.source_code)
        functions = re.findall(r'\b(?:function|def)\s+(\w+)', self.source_code)
        operations = re.findall(r'[+\-*/=]', self.source_code)
        return variables, functions, operations

    def translate_to_python(self, source_lang):
        if source_lang == 'c' or source_lang == 'cpp':
            # Convert printf/cout to print
            code = re.sub(r'printf\((.*?)\);|cout\s*<<\s*(.*?)\s*;', r'print(\1\2)', self.source_code)
            # Convert scanf/cin to input
            code = re.sub(r'scanf\(".*?",\s*&(.*?)\);|cin\s*>>\s*(.*?)\s*;', r'\1\2 = input()', code)
            return code
        elif source_lang == 'javascript':
            # Convert console.log to print
            code = re.sub(r'console\.log\((.*?)\);', r'print(\1)', self.source_code)
            # Convert let/var to Python variables
            code = re.sub(r'(?:let|var|const)\s+', '', code)
            return code
        return self.source_code

    def translate_to_cpp(self, source_lang):
        if source_lang == 'python':
            # Add necessary includes and main function
            code = '#include <iostream>\nusing namespace std;\n\nint main() {\n'
            # Convert print to cout
            code += re.sub(r'print\((.*?)\)', r'cout << \1 << endl', self.source_code)
            code += '\nreturn 0;\n}'
            return code
        return self.source_code
    
    def translate_to_java(self, source_lang):
        if source_lang == 'python':
            body = re.sub(r'print\((.*?)\)', r'System.out.println(\1);', self.source_code)
            return 'public class Main {\n    public static void main(String[] args) {\n' + body + '\n    }\n}'
        return self.source_code

    def compile(self, target_language=None):
        source_lang = self.detector.detect_language()

        if not target_language:
           
            translations = {
                'python': self.translate_to_python(source_lang),
                'cpp': self.translate_to_cpp(source_lang),
                'java' : self.translate_to_java(source_lang),
                'source': self.source_code  # Assuming Java is similar to C++ 
            }
            return source_lang, translations
        else:
            if target_language == 'python':
                return source_lang, self.translate_to_python(source_lang)
            elif target_language == 'java':
                return source_lang, self.translate_to_java(source_lang)
            elif target_language in ['cpp', 'c', 'javascript']:
                return source_lang, self.translate_to_cpp(source_lang)
            
            



class CodeExecutor:
    def __init__(self):
        # Create a directory for temporary files if it doesn't exist
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.temp_dir = os.path.join(self.base_dir,"temp")
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)

   
    # make sure this is imported at the top

    def execute_python(self, code):
        import sys  
        temp_file = os.path.join(self.temp_dir, "temp_python.py")

        with open(temp_file, "w") as f:
            f.write(code)

        try:
            # ✅ Get the correct Python interpreter path
            python_path = sys.executable

            # 🛠️ Run the Python file
            result = subprocess.run(
                [python_path, temp_file],
                capture_output=True,
                text=True,
                shell=False  # safer when using list
            )

            # ✅ Return output or error
            if result.returncode != 0:
                return f"Runtime Error:\n{result.stderr or 'Unknown error'}"

            return result.stdout if result.stdout else "⚠️ No output."

        except Exception as e:
            return f"Error: {str(e)}"


    def execute_cpp(self, code):
        temp_cpp = os.path.join(self.temp_dir, "temp_cpp.cpp")
        temp_exe = os.path.join(self.temp_dir, "temp_cpp.exe")

        with open(temp_cpp, "w") as f:
            f.write(code)
        
        try:
            # FIXED: Use raw string
            compiler = r"C:\MinGW\bin\g++.exe"

            # Check if g++ is available
            try:
                subprocess.run([compiler, "--version"], capture_output=True, check=True)
            except subprocess.CalledProcessError:
                return "Error: C++ compiler (g++) found but not working correctly."
            except FileNotFoundError:
                return "Error: C++ compiler (g++) not found at the specified path."

            # Compile the code
            compile_result = subprocess.run(
                [compiler, temp_cpp, "-o", temp_exe],
                capture_output=True,
                text=True
            )

            if compile_result.returncode != 0:
                return f"Compilation Error: {compile_result.stderr}"

            # Run the compiled executable
            run_result = subprocess.run(
                [temp_exe],
                capture_output=True,
                text=True
            )

            return run_result.stdout if run_result.stdout else run_result.stderr

        except Exception as e:
            return f"Error: {str(e)}"


        
    def execute_java(self, code):
        try:
            temp_java = os.path.join(self.temp_dir, "temp_main.java")
            with open(temp_java, "w") as f:
                f.write(code)

            compile_result = subprocess.run(
                ["javac", temp_java],
                capture_output=True,
                text=True,
                shell=True
            )

            if compile_result.returncode != 0:
                return f"Compilation Error: {compile_result.stderr}"

            run_result = subprocess.run(
                ["javac", "-cp", self.temp_dir, "Main"],
                capture_output=True,
                text=True,
                shell=True
            )

            return run_result.stdout if run_result.stdout else run_result.stderr
        except Exception as e:
            return f"Error: {str(e)}"